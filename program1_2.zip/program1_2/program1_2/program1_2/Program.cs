﻿using program1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program1
{
    public abstract class Furniture
    {
        public decimal Price { get; set; }
        public string Category { get; set; }
        public double Weight { get; set; }
        public abstract int Seat();

        //Furniture class constructor
        //precondition: price cannot be <0 or null, category cannot be whitespace or null, weight cannot be <0 or weight>1000
        //postcondition: Entered values will be stored in the price, category cand weight
        // if incorrect, error will throw
        public Furniture(decimal price, string category, double weight)
        {
            if (price < 0) throw new ArgumentOutOfRangeException("Price must be greater than zero");
            if (string.IsNullOrWhiteSpace(category)) throw new ArgumentOutOfRangeException("Category cannot be blank");
            if (weight < 0 || weight > 1000) throw new ArgumentOutOfRangeException("weight mmust be between");
            Price = price;
            Category = category;
            Weight = weight;
        }
    }
    public abstract class Seat : Furniture
    {
        public int Seats { get; set; }
        public int Legs { get; set; }

        //constructor for seat
        //precondition: seats must have a int between 0 and 24, and legs must have a value between 0-10
        //postcondition: returns data as formatted string, if incorrect data, error thrown, and 
        //a weightperleg method to calculate the amount of weight on each leg
        public Seat(decimal price, string category, double weight, int seats, int legs)
                 : base(price, category, weight)
        {
            if (seats < 0 || seats > 24) throw new ArgumentOutOfRangeException("seats must be a value between 0 and 24");
            if (legs < 0 || legs > 10) throw new ArgumentOutOfRangeException("legs must be a value between 1 and 10");

            Seats = seats;
            Legs = legs;
        }
        public double WeightPerLeg()
        {
            return Weight / Legs;
        }
        public override string ToString()
        {
            return $"Price:{Price}, Category:{Category}, Weight:{Weight}, Seats:{Seats}, Legs:{Legs}";
        }
    }

    //precondition: material must be either leather or textile
    //postcondition: display values in formatted string 
    public class Couch : Seat
    {
        public string Material { get; set; }
        public Cushion CouchCushion { get; set; }
        public Couch(decimal price, string category, double weight, int seats, int legs, string material, Cushion cushion)
                : base(price, category, weight, seats, legs)
        {
            if (material != "Leather" && material != "Textile") throw new ArgumentOutOfRangeException("material must be leather or textile");

            Material = material;
            CouchCushion = cushion;

        }
        public override int Seat()
        {
            return Seats;
        }
        public override string ToString()
        {
            return base.ToString() + $", Material: {Material}, Cushion: {CouchCushion}";
        }
    }
    //precondition:none
    //postcondition: Create deskchair and adds field for spin, displays output in tostring method

    public class DeskChair : Seat
    {
        public bool Spin { get; set; }
        public DeskChair(decimal price, string category, double weight, int seats, int legs, bool spin)
            : base(price, category, weight, seats, legs)
        {
            Spin = spin;
        }
        public override int Seat()
        {
            return Seats; 
        }
        public override string ToString()
        {
            return base.ToString() + $",Spin:{Spin}";
        }

    }
    //precondition: material must be either foam or stuffing, length width and height must all be greater than 0 
    //postcondition: will store values from input and will calculate volume of material
    public class Cushion
    {
        public string Material { get; set; }
        public double Length { get; set; }
        public double Height { get; set; }
        public double Width { get; set; }

        public Cushion(string material, double height, double width, double length)
        {
            if (material != "Foam" && material != "Stuffing") throw new ArgumentOutOfRangeException("material must be either foam or stuffing");
            if (length < 0) throw new ArgumentOutOfRangeException("length must be greater than 0 and not null");
            if (width < 0) throw new ArgumentOutOfRangeException("width must be greater than 0 and not null");
            if (height < 0) throw new ArgumentOutOfRangeException("height must be greater than 0 and not null");

            Material = material;
            Length = length;
            Height = height;
            Width = width;
        }
        public double CalcVolume()
        {
            return Length * Width * Height;
        }
        public override string ToString()
        {
            return $"Material: {Material}, Height: {Height}, Width: {Width}, Length: {Length},Volume:{CalcVolume()}";
        }
    }
}
